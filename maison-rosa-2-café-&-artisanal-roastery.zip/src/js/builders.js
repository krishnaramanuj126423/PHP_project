/* Interactive Builders Logic (Meal, Coffee Brew, Visual Plate) */
import { Cart } from './cart.js';
import { showToast } from './main.js';

// --- 1. MEAL BUILDER STATE ---
let customMeal = {
  base: { name: 'Pasta (Bronze Rigatoni)', price: 8.00, cal: 220, icon: 'fa-wheat-awn' },
  protein: { name: 'Grilled Tuscan Herb Chicken', price: 5.50, cal: 240, icon: 'fa-drumstick-bite' },
  veggies: [
    { name: 'Chanterelle Mushrooms', price: 2.00, cal: 30, icon: 'fa-shield-halved' },
    { name: 'Sun-Dried Sicilian Tomatoes', price: 1.50, cal: 40, icon: 'fa-sun' }
  ],
  sauce: { name: 'Creamy White Truffle Alfredo', price: 2.50, cal: 180, icon: 'fa-bottle-droplet' },
  extras: [
    { name: 'Aged Parmesan Shavings', price: 1.50, cal: 60, icon: 'fa-cheese' }
  ],
  spice: 'Mild'
};

// --- 2. COFFEE BREW BUILDER STATE ---
let customBrew = {
  size: { name: 'Standard (12oz Antiquity)', price: 4.50, scale: 1.0, shots: 2 },
  temp: 'Steaming Hot',
  tempType: 'hot',
  coffee: { name: 'Velvety Latte', price: 0.00, color: '#5C3826', fillPct: 70, caffeine: 150, foam: 35 },
  roast: { name: 'Ethiopia Yirgacheffe (Floral & Bergamot)' },
  shots: { name: 'Double Shot (Standard)', price: 0.00, caff: 150 },
  milk: { name: 'Barista Oat Milk', price: 0.80, color: '#F3E9D5', cal: 90 },
  flavor: { name: 'Madagascar Bourbon Vanilla', price: 0.70, cal: 60 },
  toppings: [
    { name: 'House Whipped Cream', price: 0.80, cal: 80, drizzle: '#FFFFFF' },
    { name: 'Artisanal Caramel Drizzle', price: 0.60, cal: 40, drizzle: '#C59B27' }
  ],
  sweetness: 50
};

// --- 3. VISUAL PLATE BUILDER STATE ---
let customPlate = {
  main: { name: 'Tuscan Grilled Chicken', price: 10.00, cal: 320, icon: 'fa-drumstick-bite' },
  side: { name: 'Truffle Roasted Potatoes', price: 4.50, cal: 210, icon: 'fa-bowl-food' },
  salad: { name: 'Wild Arugula & Parmesan', price: 3.50, cal: 90, icon: 'fa-seedling' },
  sauce: { name: 'Artisanal Pesto Reduction', price: 2.00, cal: 120, icon: 'fa-bottle-droplet' },
  drink: { name: 'Sparkling Citrus Tonic', price: 3.50, cal: 45, icon: 'fa-glass-water' },
  dessert: { name: 'Mini Dark Chocolate Tart', price: 4.00, cal: 180, icon: 'fa-cookie' }
};

export const Builders = {
  init() {
    this.renderMealSummary();
    this.renderBrewPreview();
    this.renderPlateCanvas();
    this.bindMealEvents();
    this.bindBrewEvents();
    this.bindPlateEvents();
  },

  // --- MEAL BUILDER METHODS ---
  renderMealSummary() {
    const totalPrice = customMeal.base.price + customMeal.protein.price +
      customMeal.veggies.reduce((s, v) => s + v.price, 0) +
      customMeal.sauce.price +
      customMeal.extras.reduce((s, e) => s + e.price, 0);

    const totalCal = customMeal.base.cal + customMeal.protein.cal +
      customMeal.veggies.reduce((s, v) => s + v.cal, 0) +
      customMeal.sauce.cal +
      customMeal.extras.reduce((s, e) => s + e.cal, 0);

    const totalItems = 2 + customMeal.veggies.length + 1 + customMeal.extras.length;

    // 1. Update Live Bowl Visualizer Elements
    const slotBase = document.getElementById('meal-slot-base');
    const slotProtein = document.getElementById('meal-slot-protein');
    const slotSauce = document.getElementById('meal-slot-sauce');
    const slotVeggies = document.getElementById('meal-slot-veggies');
    const slotExtras = document.getElementById('meal-slot-extras');

    if (slotBase) {
      slotBase.innerHTML = `<i class="fa-solid ${customMeal.base.icon || 'fa-wheat-awn'} text-amber-800"></i> ${customMeal.base.name}`;
    }
    if (slotProtein) {
      slotProtein.innerHTML = `<i class="fa-solid ${customMeal.protein.icon || 'fa-drumstick-bite'} text-red-800"></i> ${customMeal.protein.name}`;
    }
    if (slotSauce) {
      slotSauce.innerHTML = `<i class="fa-solid ${customMeal.sauce.icon || 'fa-bottle-droplet'} text-amber-900"></i> ${customMeal.sauce.name}`;
    }
    if (slotVeggies) {
      if (customMeal.veggies.length > 0) {
        slotVeggies.innerHTML = customMeal.veggies.map(v => `
          <span class="meal-layer-badge meal-badge-veggie">
            <i class="fa-solid ${v.icon || 'fa-leaf'} text-emerald-800"></i> ${v.name}
          </span>
        `).join('');
      } else {
        slotVeggies.innerHTML = `<span class="text-[10px] text-stone-400 italic">No vegetables added</span>`;
      }
    }
    if (slotExtras) {
      if (customMeal.extras.length > 0) {
        slotExtras.innerHTML = customMeal.extras.map(e => `
          <span class="meal-layer-badge meal-badge-extra">
            <i class="fa-solid ${e.icon || 'fa-sparkles'} text-purple-800"></i> ${e.name}
          </span>
        `).join('');
      } else {
        slotExtras.innerHTML = '';
      }
    }

    // 2. Update Section Selection Badges
    const badgeBase = document.getElementById('meal-badge-base');
    const badgeProtein = document.getElementById('meal-badge-protein');
    const badgeVeggies = document.getElementById('meal-badge-veggies');
    const badgeSauce = document.getElementById('meal-badge-sauce');
    const badgeExtras = document.getElementById('meal-badge-extras');

    if (badgeBase) badgeBase.textContent = `${customMeal.base.name} (₹${customMeal.base.price.toFixed(2)})`;
    if (badgeProtein) badgeProtein.textContent = `${customMeal.protein.name} (₹${customMeal.protein.price.toFixed(2)})`;
    if (badgeVeggies) badgeVeggies.textContent = `${customMeal.veggies.length} Selected (+₹${customMeal.veggies.reduce((s, v) => s + v.price, 0).toFixed(2)})`;
    if (badgeSauce) badgeSauce.textContent = `${customMeal.sauce.name} (₹${customMeal.sauce.price.toFixed(2)})`;
    if (badgeExtras) badgeExtras.textContent = `${customMeal.extras.length} Selected (+₹${customMeal.extras.reduce((s, e) => s + e.price, 0).toFixed(2)})`;

    // 3. Render Itemized Summary Box
    const summaryEl = document.getElementById('meal-summary-box');
    if (summaryEl) {
      summaryEl.innerHTML = `
        <div class="flex items-center justify-between border-b border-stone-100 pb-3 mb-3">
          <h4 class="font-serif text-lg font-bold text-stone-900">Chef's Custom Bowl Recipe</h4>
          <span class="text-[11px] bg-amber-50 text-amber-800 font-semibold px-2.5 py-1 rounded-full border border-amber-200">
            ${totalItems} Components • ${customMeal.spice}
          </span>
        </div>

        <ul class="text-xs space-y-1.5 text-stone-600 mb-4 divide-y divide-stone-50">
          <li class="flex justify-between items-center pt-1">
            <span class="font-semibold text-stone-800">1. Base:</span>
            <span class="text-stone-700">${customMeal.base.name}</span>
            <span class="font-mono text-stone-900">₹${customMeal.base.price.toFixed(2)}</span>
          </li>
          <li class="flex justify-between items-center pt-1">
            <span class="font-semibold text-stone-800">2. Protein:</span>
            <span class="text-stone-700">${customMeal.protein.name}</span>
            <span class="font-mono text-stone-900">₹${customMeal.protein.price.toFixed(2)}</span>
          </li>
          <li class="flex justify-between items-center pt-1">
            <span class="font-semibold text-stone-800">3. Veggies:</span>
            <span class="text-stone-700 truncate max-w-[180px]">${customMeal.veggies.map(v => v.name).join(', ') || 'None'}</span>
            <span class="font-mono text-stone-900">+₹${customMeal.veggies.reduce((s, v) => s + v.price, 0).toFixed(2)}</span>
          </li>
          <li class="flex justify-between items-center pt-1">
            <span class="font-semibold text-stone-800">4. Sauce:</span>
            <span class="text-stone-700">${customMeal.sauce.name}</span>
            <span class="font-mono text-stone-900">₹${customMeal.sauce.price.toFixed(2)}</span>
          </li>
          <li class="flex justify-between items-center pt-1">
            <span class="font-semibold text-stone-800">5. Garnishes:</span>
            <span class="text-stone-700 truncate max-w-[180px]">${customMeal.extras.map(e => e.name).join(', ') || 'None'}</span>
            <span class="font-mono text-stone-900">+₹${customMeal.extras.reduce((s, e) => s + e.price, 0).toFixed(2)}</span>
          </li>
          <li class="flex justify-between items-center pt-1">
            <span class="font-semibold text-stone-800">Heat Level:</span>
            <span class="text-stone-700">${customMeal.spice} Heat</span>
            <span class="text-[10px] text-stone-400 font-mono">Included</span>
          </li>
        </ul>

        <div class="pt-3 border-t border-stone-200 flex justify-between items-center mb-4">
          <div>
            <p class="text-[11px] text-stone-500 font-medium">Estimated Nutritional Energy</p>
            <p class="font-bold text-stone-900 flex items-center gap-1.5">
              <i class="fa-solid fa-fire text-amber-700 text-xs"></i> ${totalCal} Calories
            </p>
          </div>
          <div class="text-right">
            <p class="text-[11px] text-stone-500 font-medium">Custom Bowl Total</p>
            <p class="font-serif text-2xl font-bold text-stone-900">₹${totalPrice.toFixed(2)}</p>
          </div>
        </div>

        <button class="btn-rosa text-xs w-full py-3 shadow-md" onclick="Builders.addMealToCart()">
          <i class="fa-solid fa-cart-plus mr-1"></i> Add Custom Meal to Cart
        </button>
      `;
    }
  },

  addMealToCart() {
    const totalPrice = customMeal.base.price + customMeal.protein.price +
      customMeal.veggies.reduce((s, v) => s + v.price, 0) +
      customMeal.sauce.price +
      customMeal.extras.reduce((s, e) => s + e.price, 0);

    const veggieStr = customMeal.veggies.length > 0 ? ` with ${customMeal.veggies.map(v => v.name).join(' & ')}` : '';
    const extraStr = customMeal.extras.length > 0 ? ` topped with ${customMeal.extras.map(e => e.name).join(', ')}` : '';
    const details = `${customMeal.base.name} & ${customMeal.protein.name}${veggieStr} in ${customMeal.sauce.name}${extraStr} (${customMeal.spice} Heat)`;

    Cart.addItem({
      id: 'custom_meal_' + Date.now(),
      name: `Custom ${customMeal.protein.name} Bowl`,
      price: totalPrice,
      image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=600&q=80'
    }, 1, details);

    showToast(`Added Custom Bowl (₹${totalPrice.toFixed(2)}) to Cart!`);
  },

  loadMealPreset(type) {
    const presets = {
      'truffle-chicken': {
        base: { name: 'Pasta (Bronze Rigatoni)', price: 8.00, cal: 220, icon: 'fa-wheat-awn' },
        protein: { name: 'Grilled Tuscan Herb Chicken', price: 5.50, cal: 240, icon: 'fa-drumstick-bite' },
        veggies: [
          { name: 'Chanterelle Mushrooms', price: 2.00, cal: 30, icon: 'fa-shield-halved' },
          { name: 'Sun-Dried Sicilian Tomatoes', price: 1.50, cal: 40, icon: 'fa-sun' }
        ],
        sauce: { name: 'Creamy White Truffle Alfredo', price: 2.50, cal: 180, icon: 'fa-bottle-droplet' },
        extras: [
          { name: 'Aged Parmesan Shavings', price: 1.50, cal: 60, icon: 'fa-cheese' },
          { name: 'White Truffle Oil Drizzle', price: 1.80, cal: 50, icon: 'fa-droplet' }
        ],
        spice: 'Mild'
      },
      'salmon-quinoa': {
        base: { name: 'Mediterranean Herb Quinoa', price: 7.00, cal: 170, icon: 'fa-seedling' },
        protein: { name: 'Pan-Seared Atlantic Salmon', price: 7.50, cal: 280, icon: 'fa-fish' },
        veggies: [
          { name: 'Charred Garlic Broccolini', price: 2.00, cal: 45, icon: 'fa-seedling' },
          { name: 'Sun-Dried Sicilian Tomatoes', price: 1.50, cal: 40, icon: 'fa-sun' }
        ],
        sauce: { name: 'Lemon Herb Garlic Reduction', price: 2.00, cal: 110, icon: 'fa-lemon' },
        extras: [
          { name: 'Toasted Pine Nuts', price: 1.50, cal: 70, icon: 'fa-cubes-stacked' },
          { name: 'Fresh Micro-Basil', price: 0.80, cal: 5, icon: 'fa-leaf' }
        ],
        spice: 'Mild'
      },
      'shortrib-risotto': {
        base: { name: 'Saffron Carnaroli Risotto', price: 8.50, cal: 240, icon: 'fa-spoon' },
        protein: { name: 'Slow-Braised Prime Short Rib', price: 8.00, cal: 320, icon: 'fa-bacon' },
        veggies: [
          { name: 'Chanterelle Mushrooms', price: 2.00, cal: 30, icon: 'fa-shield-halved' },
          { name: 'Caramelized Cipollini Onions', price: 1.50, cal: 50, icon: 'fa-circle' }
        ],
        sauce: { name: 'San Marzano Tomato Basil', price: 2.00, cal: 90, icon: 'fa-apple-whole' },
        extras: [
          { name: 'Aged Parmesan Shavings', price: 1.50, cal: 60, icon: 'fa-cheese' },
          { name: 'Crispy Fried Shallots', price: 1.00, cal: 45, icon: 'fa-sparkles' }
        ],
        spice: 'Medium'
      },
      'vegan-bowl': {
        base: { name: 'Fresh Wild Greens Bowl', price: 7.50, cal: 90, icon: 'fa-leaf' },
        protein: { name: 'Crispy Organic Tofu Cubes', price: 4.50, cal: 180, icon: 'fa-cubes' },
        veggies: [
          { name: 'Fire-Roasted Bell Peppers', price: 1.50, cal: 35, icon: 'fa-pepper-hot' },
          { name: 'Charred Garlic Broccolini', price: 2.00, cal: 45, icon: 'fa-seedling' },
          { name: 'Sun-Dried Sicilian Tomatoes', price: 1.50, cal: 40, icon: 'fa-sun' }
        ],
        sauce: { name: 'Artisanal Basil Pesto', price: 2.50, cal: 160, icon: 'fa-mortar-pestle' },
        extras: [
          { name: 'Toasted Pine Nuts', price: 1.50, cal: 70, icon: 'fa-cubes-stacked' },
          { name: 'Fresh Micro-Basil', price: 0.80, cal: 5, icon: 'fa-leaf' }
        ],
        spice: 'Medium'
      }
    };

    if (presets[type]) {
      customMeal = JSON.parse(JSON.stringify(presets[type]));

      // Synchronize single-select pills
      this.syncMealPillSingle('.meal-option-base', customMeal.base.name);
      this.syncMealPillSingle('.meal-option-protein', customMeal.protein.name);
      this.syncMealPillSingle('.meal-option-sauce', customMeal.sauce.name);
      this.syncMealPillSingle('.meal-option-spice', customMeal.spice);

      // Synchronize multi-select pills
      const veggieNames = customMeal.veggies.map(v => v.name);
      document.querySelectorAll('.meal-option-veggie').forEach(btn => {
        if (veggieNames.includes(btn.dataset.name)) {
          btn.classList.add('selected');
        } else {
          btn.classList.remove('selected');
        }
      });

      const extraNames = customMeal.extras.map(e => e.name);
      document.querySelectorAll('.meal-option-extra').forEach(btn => {
        if (extraNames.includes(btn.dataset.name)) {
          btn.classList.add('selected');
        } else {
          btn.classList.remove('selected');
        }
      });

      this.renderMealSummary();
      showToast(`Loaded ${type.replace('-', ' ').toUpperCase()} signature meal preset!`);
    }
  },

  syncMealPillSingle(selector, activeName) {
    document.querySelectorAll(selector).forEach(btn => {
      if (btn.dataset.name === activeName) {
        btn.classList.add('selected');
      } else {
        btn.classList.remove('selected');
      }
    });
  },

  bindMealEvents() {
    // 1. Base selection
    document.querySelectorAll('.meal-option-base').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.meal-option-base').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
        customMeal.base = {
          name: btn.dataset.name,
          price: parseFloat(btn.dataset.price),
          cal: parseInt(btn.dataset.cal),
          icon: btn.dataset.icon || 'fa-wheat-awn'
        };
        this.renderMealSummary();
      });
    });

    // 2. Protein selection
    document.querySelectorAll('.meal-option-protein').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.meal-option-protein').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
        customMeal.protein = {
          name: btn.dataset.name,
          price: parseFloat(btn.dataset.price),
          cal: parseInt(btn.dataset.cal),
          icon: btn.dataset.icon || 'fa-drumstick-bite'
        };
        this.renderMealSummary();
      });
    });

    // 3. Sautéed Veggies selection (Multi-Select toggle)
    document.querySelectorAll('.meal-option-veggie').forEach(btn => {
      btn.addEventListener('click', () => {
        const name = btn.dataset.name;
        const price = parseFloat(btn.dataset.price);
        const cal = parseInt(btn.dataset.cal);
        const icon = btn.dataset.icon || 'fa-leaf';

        const existingIdx = customMeal.veggies.findIndex(v => v.name === name);
        if (existingIdx >= 0) {
          customMeal.veggies.splice(existingIdx, 1);
          btn.classList.remove('selected');
        } else {
          customMeal.veggies.push({ name, price, cal, icon });
          btn.classList.add('selected');
        }
        this.renderMealSummary();
      });
    });

    // 4. Sauce selection
    document.querySelectorAll('.meal-option-sauce').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.meal-option-sauce').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
        customMeal.sauce = {
          name: btn.dataset.name,
          price: parseFloat(btn.dataset.price),
          cal: parseInt(btn.dataset.cal),
          icon: btn.dataset.icon || 'fa-bottle-droplet'
        };
        this.renderMealSummary();
      });
    });

    // 5. Finishing Garnishes & Crunch (Multi-Select toggle)
    document.querySelectorAll('.meal-option-extra').forEach(btn => {
      btn.addEventListener('click', () => {
        const name = btn.dataset.name;
        const price = parseFloat(btn.dataset.price);
        const cal = parseInt(btn.dataset.cal);
        const icon = btn.dataset.icon || 'fa-cheese';

        const existingIdx = customMeal.extras.findIndex(e => e.name === name);
        if (existingIdx >= 0) {
          customMeal.extras.splice(existingIdx, 1);
          btn.classList.remove('selected');
        } else {
          customMeal.extras.push({ name, price, cal, icon });
          btn.classList.add('selected');
        }
        this.renderMealSummary();
      });
    });

    // 6. Spice heat level
    document.querySelectorAll('.meal-option-spice').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.meal-option-spice').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
        customMeal.spice = btn.dataset.name;
        this.renderMealSummary();
      });
    });
  },

  // --- BREW BUILDER METHODS ---
  renderBrewPreview() {
    const fillEl = document.getElementById('brew-liquid-fill');
    const foamEl = document.getElementById('brew-milk-foam');
    const drizzleEl = document.getElementById('brew-topping-drizzle');
    const dustEl = document.getElementById('brew-topping-dust');
    const whippedCreamEl = document.getElementById('brew-whipped-cream');
    const latteArtEl = document.getElementById('brew-latte-art');
    const iceLayerEl = document.getElementById('brew-ice-layer');
    const steamEl = document.getElementById('brew-steam-effect');
    const strawEl = document.getElementById('brew-straw');
    const cupAssembly = document.getElementById('brew-cup-assembly');
    const cupContainer = document.getElementById('brew-cup-container');
    const cupHandle = document.getElementById('brew-cup-handle');
    const summaryBoxEl = document.getElementById('brew-summary-box');

    const isIced = customBrew.tempType === 'iced' || customBrew.temp.includes('Ice') || customBrew.temp.includes('Nitro');
    const hasWhippedCream = customBrew.toppings.some(t => t.name.includes('Whipped Cream'));
    const drizzleTopping = customBrew.toppings.find(t => t.drizzle && !t.name.includes('Dust') && !t.name.includes('Whipped') && !t.name.includes('Gold'));
    const dustTopping = customBrew.toppings.find(t => t.name.includes('Dust') || t.name.includes('Gold') || t.name.includes('Cocoa') || t.name.includes('Cinnamon'));

    // 1. Update Live Cup Visualizer
    if (cupAssembly && customBrew.size.scale) {
      cupAssembly.style.transform = `scale(${customBrew.size.scale})`;
    }

    if (cupContainer) {
      if (isIced) {
        cupContainer.classList.add('is-iced');
      } else {
        cupContainer.classList.remove('is-iced');
      }
    }

    if (fillEl) {
      fillEl.style.height = `${customBrew.coffee.fillPct}%`;
      fillEl.style.backgroundColor = customBrew.coffee.color;
    }

    if (foamEl) {
      if (customBrew.milk.name.includes('None')) {
        foamEl.style.height = '0px';
        foamEl.style.opacity = '0';
      } else {
        foamEl.style.height = `${customBrew.coffee.foam || 32}px`;
        foamEl.style.opacity = '1';
        foamEl.style.backgroundColor = customBrew.milk.color || '#FFF8E7';
      }
    }

    // Whipped cream topping
    if (whippedCreamEl) {
      if (hasWhippedCream) {
        whippedCreamEl.style.opacity = '1';
        whippedCreamEl.style.transform = 'translateX(-50%) translateY(0)';
      } else {
        whippedCreamEl.style.opacity = '0';
        whippedCreamEl.style.transform = 'translateX(-50%) translateY(8px)';
      }
    }

    // Latte art display (if foam is present and not completely covered)
    if (latteArtEl) {
      if (!customBrew.milk.name.includes('None') && !hasWhippedCream) {
        latteArtEl.style.opacity = '0.7';
      } else {
        latteArtEl.style.opacity = '0';
      }
    }

    // Drizzle topping
    if (drizzleEl) {
      if (drizzleTopping) {
        drizzleEl.style.opacity = '1';
        drizzleEl.style.backgroundColor = drizzleTopping.drizzle || '#C59B27';
      } else {
        drizzleEl.style.opacity = '0';
      }
    }

    // Dusting topping (Cocoa / Cinnamon / Gold)
    if (dustEl) {
      if (dustTopping) {
        dustEl.style.opacity = '1';
        if (dustTopping.name.includes('Gold')) {
          dustEl.style.background = 'radial-gradient(circle, rgba(255, 215, 0, 0.7) 10%, transparent 60%)';
        } else if (dustTopping.name.includes('Cocoa')) {
          dustEl.style.background = 'radial-gradient(circle, rgba(60, 30, 15, 0.6) 20%, transparent 70%)';
        } else {
          dustEl.style.background = 'radial-gradient(circle, rgba(140, 75, 30, 0.6) 20%, transparent 70%)';
        }
      } else {
        dustEl.style.opacity = '0';
      }
    }

    if (iceLayerEl) {
      iceLayerEl.style.opacity = isIced ? '1' : '0';
    }

    if (steamEl) {
      steamEl.style.opacity = isIced ? '0' : '1';
    }

    if (strawEl) {
      strawEl.style.opacity = isIced ? '1' : '0';
      strawEl.style.transform = isIced ? 'rotate(18deg) translateY(0)' : 'rotate(18deg) translateY(-20px)';
    }

    if (cupHandle) {
      cupHandle.style.opacity = isIced ? '0' : '1';
      cupHandle.style.pointerEvents = isIced ? 'none' : 'auto';
    }

    // 2. Update Section Selection Badges
    const badgeSize = document.getElementById('brew-badge-size');
    const badgeCoffee = document.getElementById('brew-badge-coffee');
    const badgeMilk = document.getElementById('brew-badge-milk');
    const badgeFlavor = document.getElementById('brew-badge-flavor');
    const badgeToppings = document.getElementById('brew-badge-toppings');

    if (badgeSize) badgeSize.textContent = `${customBrew.size.name} • ${customBrew.temp}`;
    if (badgeCoffee) badgeCoffee.textContent = `${customBrew.coffee.name} (${customBrew.shots.name})`;
    if (badgeMilk) badgeMilk.textContent = `${customBrew.milk.name} (+₹${customBrew.milk.price.toFixed(2)})`;
    if (badgeFlavor) badgeFlavor.textContent = customBrew.flavor ? `${customBrew.flavor.name} (+₹${customBrew.flavor.price.toFixed(2)})` : 'None';
    if (badgeToppings) badgeToppings.textContent = `${customBrew.toppings.length} Selected (+₹${customBrew.toppings.reduce((s, t) => s + t.price, 0).toFixed(2)})`;

    // 3. Price, Calorie & Caffeine Totals
    const basePrice = customBrew.size.price + customBrew.coffee.price + customBrew.shots.price;
    const milkPrice = customBrew.milk.price;
    const flavorPrice = customBrew.flavor ? customBrew.flavor.price : 0;
    const toppingsPrice = customBrew.toppings.reduce((s, t) => s + t.price, 0);
    const totalPrice = basePrice + milkPrice + flavorPrice + toppingsPrice;

    const totalCal = (customBrew.coffee.cal || 10) + (customBrew.milk.cal || 0) +
      (customBrew.flavor ? customBrew.flavor.cal : 0) +
      customBrew.toppings.reduce((s, t) => s + t.cal, 0);

    const totalCaff = (customBrew.shots.caff || 150);

    // 4. Render Itemized Summary Box
    if (summaryBoxEl) {
      summaryBoxEl.innerHTML = `
        <div class="flex items-center justify-between border-b border-stone-100 pb-3 mb-3">
          <h4 class="font-serif text-lg font-bold text-stone-900">Barista's Custom Craft Recipe</h4>
          <span class="text-[11px] bg-amber-50 text-amber-800 font-semibold px-2.5 py-1 rounded-full border border-amber-200">
            ${customBrew.size.name.split(' ')[0]} • ${customBrew.temp}
          </span>
        </div>

        <ul class="text-xs space-y-1.5 text-stone-600 mb-4 divide-y divide-stone-50">
          <li class="flex justify-between items-center pt-1">
            <span class="font-semibold text-stone-800">1. Size & Base:</span>
            <span class="text-stone-700">${customBrew.size.name} • ${customBrew.coffee.name}</span>
            <span class="font-mono text-stone-900">₹${(customBrew.size.price + customBrew.coffee.price).toFixed(2)}</span>
          </li>
          <li class="flex justify-between items-center pt-1">
            <span class="font-semibold text-stone-800">2. Roast & Intensity:</span>
            <span class="text-stone-700 truncate max-w-[170px]">${customBrew.roast.name.split('(')[0]} (${customBrew.shots.name})</span>
            <span class="font-mono text-stone-900">${customBrew.shots.price > 0 ? '+₹' + customBrew.shots.price.toFixed(2) : 'Included'}</span>
          </li>
          <li class="flex justify-between items-center pt-1">
            <span class="font-semibold text-stone-800">3. Dairy / Plant Milk:</span>
            <span class="text-stone-700">${customBrew.milk.name}</span>
            <span class="font-mono text-stone-900">${customBrew.milk.price > 0 ? '+₹' + customBrew.milk.price.toFixed(2) : '₹0.00'}</span>
          </li>
          <li class="flex justify-between items-center pt-1">
            <span class="font-semibold text-stone-800">4. Craft Syrup:</span>
            <span class="text-stone-700">${customBrew.flavor ? customBrew.flavor.name : 'Pure (No Syrup)'}</span>
            <span class="font-mono text-stone-900">${customBrew.flavor && customBrew.flavor.price > 0 ? '+₹' + customBrew.flavor.price.toFixed(2) : '₹0.00'}</span>
          </li>
          <li class="flex justify-between items-center pt-1">
            <span class="font-semibold text-stone-800">5. Finishing Garnishes:</span>
            <span class="text-stone-700 truncate max-w-[170px]">${customBrew.toppings.map(t => t.name).join(', ') || 'None'}</span>
            <span class="font-mono text-stone-900">${toppingsPrice > 0 ? '+₹' + toppingsPrice.toFixed(2) : '₹0.00'}</span>
          </li>
          <li class="flex justify-between items-center pt-1">
            <span class="font-semibold text-stone-800">6. Sweetness:</span>
            <span class="text-stone-700">${customBrew.sweetness}% Sweetness</span>
            <span class="text-[10px] text-stone-400 font-mono">Included</span>
          </li>
        </ul>

        <div class="pt-3 border-t border-stone-200 grid grid-cols-2 gap-2 mb-4 bg-stone-50 p-2.5 rounded-xl">
          <div>
            <p class="text-[10px] text-stone-500 font-medium">Estimated Energy</p>
            <p class="font-bold text-stone-900 flex items-center gap-1 text-xs">
              <i class="fa-solid fa-fire text-amber-700"></i> ${totalCal} Calories
            </p>
          </div>
          <div>
            <p class="text-[10px] text-stone-500 font-medium">Caffeine Intensity</p>
            <p class="font-bold text-stone-900 flex items-center gap-1 text-xs">
              <i class="fa-solid fa-bolt text-amber-600"></i> ~${totalCaff} mg Caffeine
            </p>
          </div>
        </div>

        <div class="flex justify-between items-center mb-4">
          <p class="text-xs text-stone-500 font-medium">Custom Brew Total</p>
          <p class="font-serif text-2xl font-bold text-stone-900">₹${totalPrice.toFixed(2)}</p>
        </div>

        <button class="btn-rosa text-xs w-full py-3 shadow-md" onclick="Builders.addBrewToCart()">
          <i class="fa-solid fa-mug-hot mr-1.5"></i> Add Custom Brew to Cart
        </button>
      `;
    }
  },

  addBrewToCart() {
    const basePrice = customBrew.size.price + customBrew.coffee.price + customBrew.shots.price;
    const milkPrice = customBrew.milk.price;
    const flavorPrice = customBrew.flavor ? customBrew.flavor.price : 0;
    const toppingsPrice = customBrew.toppings.reduce((s, t) => s + t.price, 0);
    const totalPrice = basePrice + milkPrice + flavorPrice + toppingsPrice;

    const toppingStr = customBrew.toppings.length > 0 ? ` + ${customBrew.toppings.map(t => t.name).join(', ')}` : '';
    const flavorStr = customBrew.flavor && !customBrew.flavor.name.includes('None') ? ` w/ ${customBrew.flavor.name}` : '';
    const details = `${customBrew.temp} • ${customBrew.size.name} • ${customBrew.roast.name.split('(')[0]} ${customBrew.coffee.name} w/ ${customBrew.milk.name}${flavorStr}${toppingStr} (${customBrew.sweetness}% Sweet)`;

    Cart.addItem({
      id: 'custom_brew_' + Date.now(),
      name: `Custom ${customBrew.coffee.name}`,
      price: totalPrice,
      image: customBrew.tempType === 'iced'
        ? 'https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?auto=format&fit=crop&w=600&q=80'
        : 'https://images.unsplash.com/photo-1534778101976-62847782c213?auto=format&fit=crop&w=600&q=80'
    }, 1, details);

    showToast(`Added Custom Brew (₹${totalPrice.toFixed(2)}) to Cart!`);
  },

  loadBrewPreset(type) {
    const presets = {
      'madagascar-latte': {
        size: { name: 'Standard (12oz Antiquity)', price: 4.50, scale: 1.0, shots: 2 },
        temp: 'Steaming Hot',
        tempType: 'hot',
        coffee: { name: 'Velvety Latte', price: 0.00, color: '#5C3826', fillPct: 70, caffeine: 150, foam: 35 },
        roast: { name: 'Ethiopia Yirgacheffe (Floral & Bergamot)' },
        shots: { name: 'Double Shot (Standard)', price: 0.00, caff: 150 },
        milk: { name: 'Barista Oat Milk', price: 0.80, color: '#F3E9D5', cal: 90 },
        flavor: { name: 'Madagascar Bourbon Vanilla', price: 0.70, cal: 60 },
        toppings: [
          { name: 'House Whipped Cream', price: 0.80, cal: 80, drizzle: '#FFFFFF' },
          { name: 'Ceylon Cinnamon Dust', price: 0.50, cal: 5, drizzle: '#8B5A2B' }
        ],
        sweetness: 50
      },
      'caramel-coldbrew': {
        size: { name: 'Grand (16oz Artisanal)', price: 5.20, scale: 1.15, shots: 3 },
        temp: 'Over Hand-Carved Ice',
        tempType: 'iced',
        coffee: { name: 'Cold Brew Infusion', price: 0.70, color: '#1B0F09', fillPct: 85, caffeine: 200, foam: 0 },
        roast: { name: 'Colombia Supremo (Toasted Almond & Caramel)' },
        shots: { name: 'Double Shot (Standard)', price: 0.00, caff: 200 },
        milk: { name: 'Sweet Vanilla Cold Foam', price: 1.00, color: '#FFF5DE', cal: 110 },
        flavor: { name: 'House Salted Caramel', price: 0.70, cal: 70 },
        toppings: [
          { name: 'Artisanal Caramel Drizzle', price: 0.60, cal: 40, drizzle: '#C59B27' }
        ],
        sweetness: 75
      },
      'truffle-mocha': {
        size: { name: 'Standard (12oz Antiquity)', price: 4.50, scale: 1.0, shots: 2 },
        temp: 'Steaming Hot',
        tempType: 'hot',
        coffee: { name: 'Microfoam Cappuccino', price: 0.30, color: '#4A2E1B', fillPct: 60, caffeine: 150, foam: 45 },
        roast: { name: 'Italian Velvet Dark Roast (Cacao & Walnut)' },
        shots: { name: 'Triple Shot (+1 Extra)', price: 1.00, caff: 225 },
        milk: { name: 'Organic Whole Dairy Milk', price: 0.00, color: '#FFFFFF', cal: 130 },
        flavor: { name: 'Belgian Dark Mocha', price: 0.90, cal: 85 },
        toppings: [
          { name: 'House Whipped Cream', price: 0.80, cal: 80, drizzle: '#FFFFFF' },
          { name: 'Belgian Dark Cocoa Dust', price: 0.50, cal: 15, drizzle: '#3B2219' }
        ],
        sweetness: 50
      },
      'honey-macchiato': {
        size: { name: 'Small (8oz Piccolo)', price: 3.80, scale: 0.85, shots: 1 },
        temp: 'Steaming Hot',
        tempType: 'hot',
        coffee: { name: 'Cortado 1:1', price: 0.00, color: '#3D2415', fillPct: 50, caffeine: 150, foam: 20 },
        roast: { name: 'Ethiopia Yirgacheffe (Floral & Bergamot)' },
        shots: { name: 'Double Shot (Standard)', price: 0.00, caff: 150 },
        milk: { name: 'Barista Oat Milk', price: 0.80, color: '#F3E9D5', cal: 90 },
        flavor: { name: 'Lavender Blossom Honey', price: 0.80, cal: 55 },
        toppings: [
          { name: 'Ceylon Cinnamon Dust', price: 0.50, cal: 5, drizzle: '#8B5A2B' }
        ],
        sweetness: 25
      }
    };

    if (presets[type]) {
      customBrew = JSON.parse(JSON.stringify(presets[type]));

      // Synchronize single-select pills
      this.syncBrewPillSingle('.brew-option-size', customBrew.size.name);
      this.syncBrewPillSingle('.brew-option-temp', customBrew.temp);
      this.syncBrewPillSingle('.brew-option-coffee', customBrew.coffee.name);
      this.syncBrewPillSingle('.brew-option-roast', customBrew.roast.name);
      this.syncBrewPillSingle('.brew-option-shots', customBrew.shots.name);
      this.syncBrewPillSingle('.brew-option-milk', customBrew.milk.name);
      this.syncBrewPillSingle('.brew-option-flavor', customBrew.flavor ? customBrew.flavor.name : 'None (Unflavored)');

      // Synchronize multi-select toppings
      const toppingNames = customBrew.toppings.map(t => t.name);
      document.querySelectorAll('.brew-option-topping').forEach(btn => {
        if (toppingNames.includes(btn.dataset.name)) {
          btn.classList.add('selected');
        } else {
          btn.classList.remove('selected');
        }
      });

      // Synchronize sweetness slider
      const sweetSlider = document.getElementById('brew-sweetness-slider');
      const sweetVal = document.getElementById('brew-sweetness-val');
      if (sweetSlider) sweetSlider.value = customBrew.sweetness;
      if (sweetVal) sweetVal.textContent = `${customBrew.sweetness}% (${customBrew.sweetness === '0' || customBrew.sweetness === 0 ? 'Unsweetened' : customBrew.sweetness <= 25 ? 'Light' : customBrew.sweetness <= 50 ? 'Semi-Sweet' : 'Sweet'})`;

      this.renderBrewPreview();
      showToast(`Loaded ${type.replace('-', ' ').toUpperCase()} Barista Creation!`);
    }
  },

  syncBrewPillSingle(selector, activeName) {
    document.querySelectorAll(selector).forEach(btn => {
      if (btn.dataset.name === activeName) {
        btn.classList.add('selected');
      } else {
        btn.classList.remove('selected');
      }
    });
  },

  bindBrewEvents() {
    // 1. Size Selection
    document.querySelectorAll('.brew-option-size').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.brew-option-size').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
        customBrew.size = {
          name: btn.dataset.name,
          price: parseFloat(btn.dataset.price),
          scale: parseFloat(btn.dataset.scale) || 1.0,
          shots: parseInt(btn.dataset.shots) || 2
        };
        this.renderBrewPreview();
      });
    });

    // 2. Temperature Selection
    document.querySelectorAll('.brew-option-temp').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.brew-option-temp').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
        customBrew.temp = btn.dataset.name;
        customBrew.tempType = btn.dataset.tempType || 'hot';
        this.renderBrewPreview();
      });
    });

    // 3. Espresso Style Selection
    document.querySelectorAll('.brew-option-coffee').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.brew-option-coffee').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
        customBrew.coffee = {
          name: btn.dataset.name,
          price: parseFloat(btn.dataset.price),
          color: btn.dataset.color || '#5C3826',
          fillPct: parseInt(btn.dataset.fill) || 70,
          caffeine: parseInt(btn.dataset.caffeine) || 150,
          foam: parseInt(btn.dataset.foam) || 30
        };
        this.renderBrewPreview();
      });
    });

    // 4. Bean Origin Selection
    document.querySelectorAll('.brew-option-roast').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.brew-option-roast').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
        customBrew.roast = { name: btn.dataset.name };
        this.renderBrewPreview();
      });
    });

    // 5. Espresso Shot Intensity Selection
    document.querySelectorAll('.brew-option-shots').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.brew-option-shots').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
        customBrew.shots = {
          name: btn.dataset.name,
          price: parseFloat(btn.dataset.price),
          caff: parseInt(btn.dataset.caff) || 150
        };
        this.renderBrewPreview();
      });
    });

    // 6. Milk Choice Selection
    document.querySelectorAll('.brew-option-milk').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.brew-option-milk').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
        customBrew.milk = {
          name: btn.dataset.name,
          price: parseFloat(btn.dataset.price),
          color: btn.dataset.color || '#FFF',
          cal: parseInt(btn.dataset.cal) || 0
        };
        this.renderBrewPreview();
      });
    });

    // 7. Craft Flavor Selection
    document.querySelectorAll('.brew-option-flavor').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.brew-option-flavor').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
        customBrew.flavor = {
          name: btn.dataset.name,
          price: parseFloat(btn.dataset.price),
          cal: parseInt(btn.dataset.cal) || 0
        };
        this.renderBrewPreview();
      });
    });

    // 8. Finishing Toppings & Drizzles (Multi-Select toggle)
    document.querySelectorAll('.brew-option-topping').forEach(btn => {
      btn.addEventListener('click', () => {
        const name = btn.dataset.name;
        const price = parseFloat(btn.dataset.price);
        const cal = parseInt(btn.dataset.cal) || 0;
        const drizzle = btn.dataset.drizzle || '#C59B27';

        const existingIdx = customBrew.toppings.findIndex(t => t.name === name);
        if (existingIdx >= 0) {
          customBrew.toppings.splice(existingIdx, 1);
          btn.classList.remove('selected');
        } else {
          customBrew.toppings.push({ name, price, cal, drizzle });
          btn.classList.add('selected');
        }
        this.renderBrewPreview();
      });
    });

    // 9. Sweetness Slider
    const sweetSlider = document.getElementById('brew-sweetness-slider');
    const sweetVal = document.getElementById('brew-sweetness-val');
    if (sweetSlider) {
      sweetSlider.addEventListener('input', (e) => {
        customBrew.sweetness = e.target.value;
        const levelText = e.target.value === '0' || e.target.value === 0
          ? 'Unsweetened'
          : e.target.value <= 25
          ? 'Light'
          : e.target.value <= 50
          ? 'Semi-Sweet'
          : e.target.value <= 75
          ? 'Sweet'
          : 'Full Sweet';
        if (sweetVal) sweetVal.textContent = `${e.target.value}% (${levelText})`;
        this.renderBrewPreview();
      });
    }
  },

  // --- PLATE BUILDER METHODS ---
  renderPlateCanvas() {
    const slotMain = document.getElementById('plate-slot-main');
    const slotSide = document.getElementById('plate-slot-side');
    const slotSalad = document.getElementById('plate-slot-salad');
    const slotSauce = document.getElementById('plate-slot-sauce');
    const slotDrink = document.getElementById('plate-slot-drink');
    const slotDessert = document.getElementById('plate-slot-dessert');

    if (slotMain) slotMain.innerHTML = `<i class="fa-solid ${customPlate.main.icon || 'fa-drumstick-bite'} text-amber-700"></i> ${customPlate.main.name}`;
    if (slotSide) slotSide.innerHTML = `<i class="fa-solid ${customPlate.side.icon || 'fa-bowl-food'} text-amber-700"></i> ${customPlate.side.name}`;
    if (slotSalad) slotSalad.innerHTML = `<i class="fa-solid ${customPlate.salad.icon || 'fa-seedling'} text-emerald-700"></i> ${customPlate.salad.name}`;
    if (slotSauce) slotSauce.innerHTML = `<i class="fa-solid ${customPlate.sauce.icon || 'fa-bottle-droplet'} text-amber-800"></i> ${customPlate.sauce.name}`;
    if (slotDrink) slotDrink.innerHTML = `<i class="fa-solid ${customPlate.drink.icon || 'fa-glass-water'} text-amber-400"></i> ${customPlate.drink.name}`;
    if (slotDessert) slotDessert.innerHTML = `<i class="fa-solid ${customPlate.dessert.icon || 'fa-cookie'} text-white"></i> ${customPlate.dessert.name}`;

    // Update section badges
    const badgeMain = document.getElementById('plate-badge-main');
    const badgeSide = document.getElementById('plate-badge-side');
    const badgeSalad = document.getElementById('plate-badge-salad');
    const badgeSauce = document.getElementById('plate-badge-sauce');
    const badgeDrink = document.getElementById('plate-badge-drink');
    const badgeDessert = document.getElementById('plate-badge-dessert');

    if (badgeMain) badgeMain.textContent = `${customPlate.main.name} (₹${customPlate.main.price.toFixed(2)})`;
    if (badgeSide) badgeSide.textContent = `${customPlate.side.name} (₹${customPlate.side.price.toFixed(2)})`;
    if (badgeSalad) badgeSalad.textContent = `${customPlate.salad.name} (₹${customPlate.salad.price.toFixed(2)})`;
    if (badgeSauce) badgeSauce.textContent = `${customPlate.sauce.name} (₹${customPlate.sauce.price.toFixed(2)})`;
    if (badgeDrink) badgeDrink.textContent = `${customPlate.drink.name} (₹${customPlate.drink.price.toFixed(2)})`;
    if (badgeDessert) badgeDessert.textContent = `${customPlate.dessert.name} (₹${customPlate.dessert.price.toFixed(2)})`;

    const totalPrice = customPlate.main.price + customPlate.side.price +
      customPlate.salad.price + customPlate.sauce.price +
      customPlate.drink.price + customPlate.dessert.price;

    const totalCal = customPlate.main.cal + customPlate.side.cal +
      customPlate.salad.cal + customPlate.sauce.cal +
      customPlate.drink.cal + customPlate.dessert.cal;

    const summaryEl = document.getElementById('plate-summary-box');
    if (summaryEl) {
      summaryEl.innerHTML = `
        <div class="flex items-center justify-between border-b border-stone-100 pb-3 mb-3">
          <h4 class="font-serif text-lg font-bold text-stone-900">Grand Plate Bill of Fare</h4>
          <span class="text-[11px] bg-amber-50 text-amber-800 font-semibold px-2.5 py-1 rounded-full border border-amber-200">
            6 Selected Items
          </span>
        </div>

        <ul class="text-xs space-y-1.5 text-stone-600 mb-4 divide-y divide-stone-50">
          <li class="flex justify-between items-center pt-1"><span class="font-semibold text-stone-800">1. Main:</span> <span class="text-stone-700">${customPlate.main.name}</span> <span class="font-mono text-stone-900">₹${customPlate.main.price.toFixed(2)}</span></li>
          <li class="flex justify-between items-center pt-1"><span class="font-semibold text-stone-800">2. Side:</span> <span class="text-stone-700">${customPlate.side.name}</span> <span class="font-mono text-stone-900">₹${customPlate.side.price.toFixed(2)}</span></li>
          <li class="flex justify-between items-center pt-1"><span class="font-semibold text-stone-800">3. Salad:</span> <span class="text-stone-700">${customPlate.salad.name}</span> <span class="font-mono text-stone-900">₹${customPlate.salad.price.toFixed(2)}</span></li>
          <li class="flex justify-between items-center pt-1"><span class="font-semibold text-stone-800">4. Drizzle:</span> <span class="text-stone-700">${customPlate.sauce.name}</span> <span class="font-mono text-stone-900">₹${customPlate.sauce.price.toFixed(2)}</span></li>
          <li class="flex justify-between items-center pt-1"><span class="font-semibold text-stone-800">5. Drink:</span> <span class="text-stone-700">${customPlate.drink.name}</span> <span class="font-mono text-stone-900">₹${customPlate.drink.price.toFixed(2)}</span></li>
          <li class="flex justify-between items-center pt-1"><span class="font-semibold text-stone-800">6. Dessert:</span> <span class="text-stone-700">${customPlate.dessert.name}</span> <span class="font-mono text-stone-900">₹${customPlate.dessert.price.toFixed(2)}</span></li>
        </ul>

        <div class="pt-3 border-t border-stone-200 flex justify-between items-center mb-4">
          <div>
            <p class="text-[11px] text-stone-500 font-medium">Estimated Nutritional Energy</p>
            <p class="font-bold text-stone-900 flex items-center gap-1.5">
              <i class="fa-solid fa-fire text-amber-700 text-xs"></i> ${totalCal} Calories
            </p>
          </div>
          <div class="text-right">
            <p class="text-[11px] text-stone-500 font-medium">Combination Total</p>
            <p class="font-serif text-2xl font-bold text-stone-900">₹${totalPrice.toFixed(2)}</p>
          </div>
        </div>

        <div class="space-y-2">
          <button class="btn-rosa text-xs w-full py-3 shadow-md" onclick="Builders.addPlateToCart()">
            <i class="fa-solid fa-cart-plus mr-1"></i> Add Custom Grand Plate to Cart
          </button>
        </div>
      `;
    }
  },

  addPlateToCart() {
    const totalPrice = customPlate.main.price + customPlate.side.price +
      customPlate.salad.price + customPlate.sauce.price +
      customPlate.drink.price + customPlate.dessert.price;

    const details = `${customPlate.main.name} with ${customPlate.side.name}, ${customPlate.salad.name}, ${customPlate.sauce.name}, ${customPlate.drink.name} & ${customPlate.dessert.name}`;

    Cart.addItem({
      id: 'custom_plate_' + Date.now(),
      name: 'Custom Artisanal Grand Plate',
      price: totalPrice,
      image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=600&q=80'
    }, 1, details);

    showToast(`Added Grand Plate (₹${totalPrice.toFixed(2)}) to Cart!`);
  },

  loadPlatePreset(type) {
    const presets = {
      tuscan: {
        main: { name: 'Tuscan Grilled Chicken', price: 10.00, cal: 320, icon: 'fa-drumstick-bite' },
        side: { name: 'Truffle Roasted Potatoes', price: 4.50, cal: 210, icon: 'fa-bowl-food' },
        salad: { name: 'Wild Arugula & Parmesan', price: 3.50, cal: 90, icon: 'fa-seedling' },
        sauce: { name: 'Artisanal Pesto Reduction', price: 2.00, cal: 120, icon: 'fa-bottle-droplet' },
        drink: { name: 'Sparkling Citrus Tonic', price: 3.50, cal: 45, icon: 'fa-glass-water' },
        dessert: { name: 'Mini Dark Chocolate Tart', price: 4.00, cal: 180, icon: 'fa-cookie' }
      },
      salmon: {
        main: { name: 'Pan-Seared Salmon Fillet', price: 13.50, cal: 380, icon: 'fa-fish' },
        side: { name: 'French Butter Haricots Verts', price: 3.50, cal: 60, icon: 'fa-seedling' },
        salad: { name: 'Citrus Fennel Slaw', price: 3.50, cal: 70, icon: 'fa-lemon' },
        sauce: { name: 'Chimichurri Herb Butter', price: 2.00, cal: 110, icon: 'fa-cubes-stacked' },
        drink: { name: 'Iced Peach White Tea', price: 3.50, cal: 30, icon: 'fa-leaf' },
        dessert: { name: 'Lemon Ricotta Tartlet', price: 4.00, cal: 160, icon: 'fa-sun' }
      },
      truffle: {
        main: { name: 'Truffle Mushroom Rigatoni', price: 11.00, cal: 290, icon: 'fa-wheat-awn' },
        side: { name: 'Rosemary Garlic Focaccia', price: 3.50, cal: 180, icon: 'fa-bread-slice' },
        salad: { name: 'Heirloom Caprese & Basil', price: 4.50, cal: 130, icon: 'fa-apple-whole' },
        sauce: { name: 'Aged Modena Balsamic Glaze', price: 1.50, cal: 60, icon: 'fa-wine-bottle' },
        drink: { name: 'Single-Origin Cold Brew', price: 4.50, cal: 15, icon: 'fa-mug-hot' },
        dessert: { name: 'Pistachio Cardamom Cannoli', price: 4.50, cal: 210, icon: 'fa-cookie-bite' }
      },
      garden: {
        main: { name: 'Roasted Golden Cauliflower', price: 9.50, cal: 180, icon: 'fa-leaf' },
        side: { name: 'Crispy Sweet Potato Wedges', price: 4.00, cal: 160, icon: 'fa-carrot' },
        salad: { name: 'Lemon Herb Quinoa', price: 4.00, cal: 140, icon: 'fa-bowl-rice' },
        sauce: { name: 'Artisanal Pesto Reduction', price: 2.00, cal: 120, icon: 'fa-bottle-droplet' },
        drink: { name: 'Hibiscus Rosehip Berry Spritz', price: 4.00, cal: 40, icon: 'fa-martini-glass-citrus' },
        dessert: { name: 'Artisanal Macaron Duo', price: 3.80, cal: 140, icon: 'fa-circle-dot' }
      }
    };

    if (presets[type]) {
      customPlate = { ...presets[type] };

      // Update UI active classes on button pills
      this.syncPlatePillState('.plate-option-main', customPlate.main.name);
      this.syncPlatePillState('.plate-option-side', customPlate.side.name);
      this.syncPlatePillState('.plate-option-salad', customPlate.salad.name);
      this.syncPlatePillState('.plate-option-sauce', customPlate.sauce.name);
      this.syncPlatePillState('.plate-option-drink', customPlate.drink.name);
      this.syncPlatePillState('.plate-option-dessert', customPlate.dessert.name);

      this.renderPlateCanvas();
      showToast(`Loaded ${type.charAt(0).toUpperCase() + type.slice(1)} Grand Plate preset!`);
    }
  },

  syncPlatePillState(selector, activeName) {
    document.querySelectorAll(selector).forEach(btn => {
      if (btn.dataset.name === activeName) {
        btn.classList.add('selected');
      } else {
        btn.classList.remove('selected');
      }
    });
  },

  bindPlateEvents() {
    // Main course selection
    document.querySelectorAll('.plate-option-main').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.plate-option-main').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
        customPlate.main = {
          name: btn.dataset.name,
          price: parseFloat(btn.dataset.price),
          cal: parseInt(btn.dataset.cal),
          icon: btn.dataset.icon || 'fa-drumstick-bite'
        };
        this.renderPlateCanvas();
      });
    });

    // Side selection
    document.querySelectorAll('.plate-option-side').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.plate-option-side').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
        customPlate.side = {
          name: btn.dataset.name,
          price: parseFloat(btn.dataset.price),
          cal: parseInt(btn.dataset.cal),
          icon: btn.dataset.icon || 'fa-bowl-food'
        };
        this.renderPlateCanvas();
      });
    });

    // Salad selection
    document.querySelectorAll('.plate-option-salad').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.plate-option-salad').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
        customPlate.salad = {
          name: btn.dataset.name,
          price: parseFloat(btn.dataset.price),
          cal: parseInt(btn.dataset.cal),
          icon: btn.dataset.icon || 'fa-seedling'
        };
        this.renderPlateCanvas();
      });
    });

    // Sauce selection
    document.querySelectorAll('.plate-option-sauce').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.plate-option-sauce').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
        customPlate.sauce = {
          name: btn.dataset.name,
          price: parseFloat(btn.dataset.price),
          cal: parseInt(btn.dataset.cal),
          icon: btn.dataset.icon || 'fa-bottle-droplet'
        };
        this.renderPlateCanvas();
      });
    });

    // Drink selection
    document.querySelectorAll('.plate-option-drink').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.plate-option-drink').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
        customPlate.drink = {
          name: btn.dataset.name,
          price: parseFloat(btn.dataset.price),
          cal: parseInt(btn.dataset.cal),
          icon: btn.dataset.icon || 'fa-glass-water'
        };
        this.renderPlateCanvas();
      });
    });

    // Dessert selection
    document.querySelectorAll('.plate-option-dessert').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.plate-option-dessert').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
        customPlate.dessert = {
          name: btn.dataset.name,
          price: parseFloat(btn.dataset.price),
          cal: parseInt(btn.dataset.cal),
          icon: btn.dataset.icon || 'fa-cookie'
        };
        this.renderPlateCanvas();
      });
    });
  }
};

window.Builders = Builders;
