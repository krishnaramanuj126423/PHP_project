import fs from 'fs';
import path from 'path';

const DB_FILE = path.join(process.cwd(), 'database', 'cafe_data.json');

export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  description: string;
  image: string;
  ingredients: string[];
  calories: number;
  isVegetarian: boolean;
  isVegan: boolean;
  spiceLevel: number;
  allergens: string[];
  rating: number;
  reviewsCount: number;
  isBestseller: boolean;
  isNew: boolean;
  isFeatured: boolean;
  stock: number;
}

export interface Coupon {
  code: string;
  discountPercent: number;
  discountFixed: number;
  minOrder: number;
  expiry: string;
  description: string;
}

export interface ChatbotFaq {
  keyword: string;
  question: string;
  answer: string;
}

export interface OrderItem {
  name: string;
  quantity: number;
  price: number;
  customDetails?: string;
}

export interface Order {
  id: string;
  customerName: string;
  email: string;
  phone: string;
  orderType: string;
  address: string;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  tax: number;
  deliveryFee: number;
  total: number;
  status: 'Order Received' | 'Confirmed' | 'Preparing' | 'Ready' | 'Out for Delivery' | 'Delivered' | 'Cancelled';
  paymentMethod?: string;
  paymentStatus?: 'Paid' | 'Pending' | 'Failed';
  razorpayOrderId?: string;
  razorpayPaymentId?: string;
  createdAt: string;
}

export interface LoyaltyHistoryItem {
  id: string;
  date: string;
  title: string;
  stampsChange: number;
  pointsChange: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  role: 'customer' | 'admin';
  stamps?: number;
  points?: number;
  flavourProfile?: string;
  savedCreations?: any[];
  loyaltyHistory?: LoyaltyHistoryItem[];
  vouchers?: any[];
  lastCheckIn?: string;
  checkInStreak?: number;
}

export interface DatabaseSchema {
  products: Product[];
  categories: string[];
  quizQuestions: any[];
  flavourProfiles: Record<string, any>;
  loyaltyRewards: any[];
  coupons: Coupon[];
  chatbotFaq: ChatbotFaq[];
  users: User[];
  orders: Order[];
}

let cachedDb: DatabaseSchema | null = null;

export function getDb(): DatabaseSchema {
  if (cachedDb) return cachedDb;
  try {
    if (fs.existsSync(DB_FILE)) {
      const data = fs.readFileSync(DB_FILE, 'utf-8');
      cachedDb = JSON.parse(data);
      return cachedDb!;
    }
  } catch (err) {
    console.error('Error reading DB_FILE:', err);
  }
  return {
    products: [],
    categories: [],
    quizQuestions: [],
    flavourProfiles: {},
    loyaltyRewards: [],
    coupons: [],
    chatbotFaq: [],
    users: [],
    orders: []
  };
}

export function saveDb(db: DatabaseSchema) {
  cachedDb = db;
  try {
    const dir = path.dirname(DB_FILE);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving DB_FILE:', err);
  }
}
